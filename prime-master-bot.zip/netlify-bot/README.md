# 🤖 PRIME MASTER WA Bot — Panduan Deploy Netlify

## Perintah Bot
| Ketik | Fungsi |
|-------|--------|
| `/cek SMG-20260310-001` | Cek detail record by kode |
| `/pending` | Lihat semua unit pending |
| `/terbaru` | 5 record terbaru |
| `/menu` | Tampilkan menu |

---

## Cara Deploy ke Netlify

### 1. Upload ke GitHub
1. Buat akun GitHub (github.com) kalau belum ada
2. Buat repository baru → nama: `prime-master-bot`
3. Upload 3 file ini:
   - `netlify/functions/webhook.js`
   - `netlify.toml`
   - `package.json`

### 2. Deploy ke Netlify
1. Buka netlify.com → Login/daftar gratis
2. Klik **"Add new site"** → **"Import an existing project"**
3. Pilih **GitHub** → pilih repo `prime-master-bot`
4. Klik **Deploy site**
5. Tunggu deploy selesai (~1 menit)
6. Copy URL site kamu, contoh: `https://amazing-bot-123.netlify.app`

### 3. Set Environment Variables di Netlify
1. Buka **Site settings** → **Environment variables**
2. Tambah variabel berikut:

| Key | Value |
|-----|-------|
| `FONNTE_TOKEN` | `LknmUetYdv88hc5jCf1W` |
| `FIREBASE_KEY` | `AIzaSyAGOEil_dMFRlLwv5MB_psvtVdtDbC3uWU` |
| `PROJECT_ID` | `webnote-b018d` |
| `ADMIN_NUMBER` | `628xxxxxxxxxx` (nomor WA admin) |

3. Klik **Save** → **Trigger deploy** ulang

### 4. Set Webhook di Fonnte
1. Login ke fonnte.com
2. Buka **Device** → pilih device kamu
3. Cari pengaturan **Webhook / Auto Reply**
4. Isi URL webhook:
   ```
   https://[nama-site-kamu].netlify.app/.netlify/functions/webhook
   ```
5. Simpan

### 5. Test Bot
Kirim pesan WA ke nomor Fonnte kamu:
- Ketik `/menu` → harusnya balas menu
- Ketik `/cek SMG-20260310-001` → balas detail record

---

## Troubleshooting
- **Bot tidak balas** → Cek webhook URL sudah benar di Fonnte
- **Data tidak ditemukan** → Pastikan kode record benar (huruf besar)
- **Error di Netlify** → Cek Functions log di dashboard Netlify
